<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MonAnDaThich extends Model
{
    protected $table = 'MonAnDaThich';
}

<?php $__env->startSection('active_taikhoan'); ?>class="active has-sub"<?php $__env->stopSection(); ?>
<?php $__env->startSection('url'); ?>../<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('CTNA.taikhoan')); ?>"><button class='btn btn-dark' style='margin:0 0 15px 20px'>Quay lại</button></a>
<?php $__currentLoopData = $chitiet_taikhoan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chitiet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!--nút Trại thái-->
<?php if($chitiet->TrangThai == 1): ?>
        <button data-url="<?php echo e(route('CTNA.lockout_taikhoan',['id'=>$chitiet->username])); ?>" id="lockout_taikhoan" 
            class='btn btn-danger' style='margin:0 0 15px 5px'>Khóa tài khoản</button>
        
        <button data-url="<?php echo e(route('CTNA.open_taikhoan',['id'=>$chitiet->username])); ?>" id="open_taikhoan" 
            class='btn btn-info' style='display: none;margin:0 0 15px 5px'> Mởi tài khoản</button>
<?php else: ?>
        <button data-url="<?php echo e(route('CTNA.open_taikhoan',['id'=>$chitiet->username])); ?>" id="open_taikhoan" 
            class='btn btn-info' style='margin:0 0 15px 5px'> Mởi tài khoản</button>
        
        <button data-url="<?php echo e(route('CTNA.lockout_taikhoan',['id'=>$chitiet->username])); ?>" id="lockout_taikhoan" 
            class='btn btn-danger' style='display: none;margin:0 0 15px 5px'>Khóa tài khoản</button>
<?php endif; ?>
<!--cập nhật-->
<div class='form-create' >
    <form action=<?php echo e(route('CTNA.update_taikhoan',['id'=>$chitiet->username])); ?> method='POST' enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
        <div class="row">
            <h4 style='font-style: italic;'>Thông tin tài khoản</h4>
            <?php if($chitiet->TrangThai == 1): ?>
            <h4 style='font-style: italic; color:rgb(0, 255, 0)' id="txt_danghoatdong">: Đang hoạt động</h4>
            
            <h4 style='display: none;font-style: italic; color:rgb(255, 0, 0)' id="txt_dakhoa">: Đã khoá</h4>
            <?php else: ?>
            <h4 style='font-style: italic; color:rgb(255, 0, 0)' id="txt_dakhoa">: Đã khoá</h4>
            
            <h4 style='display: none;font-style: italic; color:rgb(0, 255, 0)' id="txt_danghoatdong">: Đang hoạt động</h4>
            <?php endif; ?>
        </div>
        <div class='hr'></div>
        <!--thông báo từ session-->
        <?php if(session('thong_diep')): ?>
        <div class="alert alert-success">
            <?php echo e(session('thong_diep')); ?>

        </div>
        <?php endif; ?>
        <div class='row'>
            <div class='col-sm-8'>
                <div class='row'>
                    <div class='col-sm-6'>
                        <div class='form-group'>
                            <label for="TaiKhoan">Tài khoản</label>
                            <input type="text" class='form-control' name='TaiKhoan' value='<?php echo e($chitiet->username); ?>' readonly>
                        </div>                   
                    </div>
                    <div class='col-sm-6'>
                        <div class='form-group'>
                            <label for="MatKhau">Mật khẩu</label>
                            <input type="password" class='form-control <?php if ($errors->has('MatKhau')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('MatKhau'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>' name='MatKhau' placeholder='********' >
                            <?php if ($errors->has('MatKhau')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('MatKhau'); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                </div>
                <div class='form-group'>
                    <label for="HoTen">Họ tên</label>
                    <input type="text" class='form-control <?php if ($errors->has('HoTen')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('HoTen'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>' name='HoTen' value='<?php echo e($chitiet->HoTen); ?>' required>
                    <?php if ($errors->has('HoTen')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('HoTen'); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class='form-group'>
                    <label for="SDT">Số Điện Thoại</label>
                    <input type="number" class='form-control <?php if ($errors->has('SDT')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('SDT'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>' name='SDT' value='<?php echo e($chitiet->SDT); ?>' required>
                    <?php if ($errors->has('SDT')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('SDT'); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class='form-group'>
                    <label for="Email">Email</label>
                    <input type="email" class='form-control <?php if ($errors->has('Email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>' name='Email' value='<?php echo e($chitiet->Email); ?>' required>
                    <?php if ($errors->has('Email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Email'); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>
            <div class='col-sm-4'>
                <div class='form-group'>
                    <label for="img_Avatar">Ảnh đại diện</label>
                    <img src="../images/Avatar/<?php echo e($chitiet->AnhDaiDien); ?>" alt="AnhDaiDien" name='img_Avatar' id='img_Avatar' 
                    style='width: 100%; height: 260px'>
                    <span class='btn-file btn btn-outline-dark'>
                    <input type="file" class='<?php if ($errors->has('inp_Avatar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('inp_Avatar'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>' name="inp_Avatar" id='inp_Avatar' >Chọn hình</span>
                    <?php if ($errors->has('inp_Avatar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('inp_Avatar'); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>
        </div>
        <button class='btn btn-primary' style='width:100%'>Cập nhật</button>
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div> 
    <button style='margin:20px 0px 10px 20px' id="mondatao" class='btn btn-info'>Món ăn đã tạo</button>
    <button style='margin:20px 0px 10px 0px' id="mondathich" class='btn btn-info'>Món ăn đã thích</button>
<div class='form-create'> 
<!--Món ăn đã tạo-->
<form id="formmondatao" >
    <h4 style='font-style: italic;'>Món ăn đã tạo</h4>
    <div class='hr'></div>
    <div class='form-group'>
        <table class='table'>
            <thead class='thead-dark' style='text-align: center'>
                <tr>
                    <th>Mã món</th>
                    <th>Tên món</th>
                    <th>Ghi chú</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $mondatao_taikhoan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chitiet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style='text-align: center'>
                    <td style='padding:10px 0'><?php echo e($chitiet->MaMon); ?></td>
                    <td style='padding:10px 0'><?php echo e($chitiet->TenMon); ?></td>
                    <td style='padding:10px 0'><a href="<?php echo e(route('CTNA.show_monan',['id'=>$chitiet->MaMon])); ?>">
                        <button type='button' class='btn btn-info'>Chi tiết</button></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</form>
<!--Món ăn đã thích-->
<form id="formmondathich" style="display: none;">
    <h4 style='font-style: italic;'>Món ăn đã thích</h4>
    <div class='hr'></div>
    <div class='form-group'>
        <table class='table'>
            <thead class='thead-dark' style='text-align: center'>
                <tr>
                    <th>Mã món</th>
                    <th>Tên món</th>
                    <th>Ghi chú</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $mondathich_taikhoan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chitiet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style='text-align: center'>
                    <td style='padding:10px 0'><?php echo e($chitiet->MaMon); ?></td>
                    <td style='padding:10px 0'><?php echo e($chitiet->TenMon); ?></td>
                    <td style='padding:10px 0'><a href="<?php echo e(route('CTNA.show_monan',['id'=>$chitiet->MaMon])); ?>">
                        <button type='button' class='btn btn-info'>Chi tiết</button></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</form> 
</div>

<script src="<?php echo e(URL::asset('vendor/jquery-3.2.1.min.js')); ?>"></script>
<script>
$(document).ready(function(){
// món đã tạo
$("#mondatao").click(function(){
    $("#formmondatao").show();
    $("#formmondathich").hide();
  });
// món đã thích
$("#mondathich").click(function(){
    $("#formmondatao").hide();
    $("#formmondathich").show();
  });
});
 // khoá tài khoản
 $("#lockout_taikhoan").click(function(e){
    e.preventDefault();
    var _token = $('input[name="_token"]').val();
    var url = $(this).attr('data-url');
    if(confirm("Bạn có muốn khoá không?")){  
        $.ajax({
            type: 'get',
            url: url,
            success:function(response){
                $("#lockout_taikhoan").hide();
                $("#txt_danghoatdong").hide();
                $("#open_taikhoan").show();
                $("#txt_dakhoa").show();
            },
            error: function(response){
                alert(response.error);
            }
        });
    }else{  return false;}
});
// mở tài khoản
$("#open_taikhoan").click(function(e){
    e.preventDefault();
    var _token = $('input[name="_token"]').val();
    var url = $(this).attr('data-url');

    if(confirm("Bạn có muốn mở tài khoản không?")){  
        $.ajax({
            type: 'get',
            url: url,
            success:function(response){
                $("#open_taikhoan").hide();
                $("#txt_dakhoa").hide();
                $("#lockout_taikhoan").show();
                $("#txt_danghoatdong").show();
            },
            error: function(response){
                alert(response.error);
            }
        });
    }else{  return false;}
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Subject\Laravel\BaiTap\CongThucNauAn\resources\views/chitiet_taikhoan.blade.php ENDPATH**/ ?>
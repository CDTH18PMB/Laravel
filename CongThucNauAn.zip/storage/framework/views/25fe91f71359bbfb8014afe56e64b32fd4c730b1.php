<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('CTNA.danhmuc')); ?>"><button class='btn btn-dark' style='margin:0 0 15px 20px'>Quay lại</button></a>
<form action="<?php echo e(route('CTNA.store_danhmuc')); ?>" method='POST'>
    <?php echo csrf_field(); ?>
    <div class='form-create'>
    <div class='form-group'>
            <label for="LoaiMon">Tên Loại</label>
            <input type="text" class='form-control' name='TenLoai'>
        </div>
        <div class='form-group'>
            <label for="LoaiMon">Trạng Thái</label>
            <input type="text" class='form-control' name='TrangThai'>
        </div>
        <button type='submit' class='btn btn-primary'>Thêm</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Subject\Laravel\BaiTap\CongThucNauAn\resources\views/create_danhmuc.blade.php ENDPATH**/ ?>
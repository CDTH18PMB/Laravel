<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('/header/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="<?php echo e(route('CTNA.index')); ?>">
                    <img src="<?php echo $__env->yieldContent('url'); ?>images/icon/logo.png" alt="Cool Admin" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li <?php echo $__env->yieldContent('active_index'); ?>>
                            <a class="js-arrow" href="<?php echo e(route('CTNA.index')); ?>"><i class="fas fa-book"></i>Món ăn</a>
                        </li>
                        <li <?php echo $__env->yieldContent('active_danhmuc'); ?>>
                            <a class="js-arrow" href="<?php echo e(route('CTNA.danhmuc')); ?>"><i class="fas fa-list"></i>Danh mục</a>
                        </li>
                        <li <?php echo $__env->yieldContent('active_duyet'); ?>>
                            <a class="js-arrow" href="<?php echo e(route('CTNA.duyet')); ?>"><i class="fas fa-book"></i>Công Thức đang chờ</a>
                        </li>
                        <li <?php echo $__env->yieldContent('active_binhluan'); ?>>
                            <a class="js-arrow" href="<?php echo e(route('CTNA.binhluan')); ?>"><i class="fas fa-comment"></i>Bình luận</a>
                        </li>
                        <li <?php echo $__env->yieldContent('active_taikhoan'); ?>>
                            <a class="js-arrow" href="<?php echo e(route('CTNA.taikhoan')); ?>"><i class="fas fa-user"></i>Tài khoản</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <div class="header-button">
                                <div class="noti-wrap">
                                    <!--
                                    <div class="noti__item js-item-menu">
                                        <i class="zmdi zmdi-email"></i>
                                        <span class="quantity">1</span>
                                        <div class="email-dropdown js-dropdown">
                                            <div class="email__title">
                                                <p>You have 3 New Emails</p>
                                            </div>
                                            <div class="email__item">
                                                <div class="image img-cir img-40">
                                                    <img src="<?php echo $__env->yieldContent('url'); ?>images/icon/avatar-06.jpg" alt="Cynthia Harvey" />
                                                </div>
                                                <div class="content">
                                                    <p>Meeting about new dashboard...</p>
                                                    <span>Cynthia Harvey, 3 min ago</span>
                                                </div>
                                            </div>
                                            <div class="email__item">
                                                <div class="image img-cir img-40">
                                                    <img src="<?php echo $__env->yieldContent('url'); ?>images/icon/avatar-05.jpg" alt="Cynthia Harvey" />
                                                </div>
                                                <div class="content">
                                                    <p>Meeting about new dashboard...</p>
                                                    <span>Cynthia Harvey, Yesterday</span>
                                                </div>
                                            </div>
                                            <div class="email__item">
                                                <div class="image img-cir img-40">
                                                    <img src="<?php echo $__env->yieldContent('url'); ?>images/icon/avatar-04.jpg" alt="Cynthia Harvey" />
                                                </div>
                                                <div class="content">
                                                    <p>Meeting about new dashboard...</p>
                                                    <span>Cynthia Harvey, April 12,,2018</span>
                                                </div>
                                            </div>
                                            <div class="email__footer">
                                                <a href="#">See all emails</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                -->
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="<?php echo $__env->yieldContent('url'); ?>images/icon/avatar-01.jpg" alt="John Doe" />
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#">john doe</a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <img src="<?php echo $__env->yieldContent('url'); ?>images/icon/avatar-01.jpg" alt="John Doe" />
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#">john doe</a>
                                                    </h5>
                                                    <span class="email">johndoe@example.com</span>
                                                </div>
                                            </div>
        
                                            <div class="account-dropdown__footer">
                                                <a href="#">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>

    </div>
</body>
    <?php echo $__env->make('/footer/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <script>
        function readURL(input, idIMG) { 
            if (input.files && input.files[0]) { 
            var reader = new FileReader(); 
            reader.onload = function(e) { 
                $(idIMG).attr('src', e.target.result); 
            } 
            reader.readAsDataURL(input.files[0]); 
            }       
        }   

        //Tài khoản
        $("#inp_Avatar").change(function() { 
            readURL(this, "#img_Avatar"); 
        });
        
        //Món ăn
        $("#inp_MonAn").change(function() { 
            readURL(this, "#img_MonAn"); 
        });

        $("#inp_Create_MonAn").change(function() { 
            readURL(this, "#img_Create_MonAn"); 
        });


    </script>
</html>
<!-- end document-->
<?php /**PATH C:\Users\HoangLam\Desktop\CongThucNauAn\resources\views/layout.blade.php ENDPATH**/ ?>
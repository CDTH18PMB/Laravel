<?php $__env->startSection('active_index'); ?>class="active has-sub"<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class='row' style='margin: 0 20px 10px 20px'>
    <?php if(session('create_success')): ?> <!--thêm món ăn thành công-->
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong><?php echo e(session('create_success')); ?></strong>
    </div>
    <?php endif; ?>

    <?php if(session('update_success')): ?> <!-- cập nhật thành công -->
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong><?php echo e(session('update_success')); ?></strong>
    </div>
    <?php endif; ?>

    <?php if(session('delete_success')): ?> <!-- xóa thành công -->
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong><?php echo e(session('delete_success')); ?></strong>
    </div>
    <?php endif; ?>

    <div class='col-sm-4'>
        <!-- Thêm mới -->
        <a href="<?php echo e(route('CTNA.create_monan')); ?>"><button class='btn btn-primary' style='margin-right:5px'>Thêm</button></a>
        <!-- Lọc -->
        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#filter" style='margin-right:5px'>Lọc</button>
        <!-- Sắp xếp -->
        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#sort" style='margin-right:5px'>Sắp xếp</button>
    </div>
    
    <div class='col-sm-8'>
        <!-- tìm kiếm -->
        <input type="text" class='form-control' placeholder='Tìm món ăn' style='width:100%;' id='search_mon_an'>
        <div id='SearchResult'></div>
    </div>
    


    <!-- modal bộ lọc -->
    <div class="modal fade" id="filter">
    <div class="modal-dialog">
        <div class="modal-content">
        <form name="FilterForm">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">BỘ LỌC</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                <div class=form-group>
                    <label for="filter">Loại món</label>
                    <select class='form-control' name="filter" id="filter">
                        <?php $__currentLoopData = $dsDanhMuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ds->MaLoai); ?>"><?php echo e($ds->TenLoai); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <!-- Modal footer -->
            <div class="modal-footer">
                <button type='button' class='btn btn-success'>Lọc</button>
            </div>
        </form>
        </div>
    </div>
    </div>
</div>

<div class='form-create'>
    <table class='table'>
        <thead class='thead-dark'>
            <tr class='size-14'>
                <th>Mã món</th>
                <th>Tên món</th>
                <th>Ảnh đại diện</th>
                <th>Độ khó</th>
                <th>Thời gian nấu</th>
                <th>Người tạo</th>
                <th>Trạng thái</th>
                <th>Ghi chú</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dsMonAn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr class='size-12'>
                <td style='padding:70px 0'><?php echo e($monan->MaMon); ?></td>
                <td style='padding:70px 0'><?php echo e($monan->TenMon); ?></td>
                <td><img src="images/<?php echo e($monan->TenMon); ?>/anhdaidien.jpg" alt="image" style='width:250px; height:150px'></td>
                <td style='padding:70px 0'><?php echo e($monan->DoKho); ?></td>
                <td style='padding:70px 0'><?php echo e($monan->ThoiGianNau); ?></td>
                <td style='padding:70px 0'><?php echo e($monan->NguoiTao); ?></td>
                <td style='padding:70px 0'>
                    <?php if($monan->TrangThai == 0): ?> Ngưng Hoạt động
                    <?php else: ?> Hoạt động
                    <?php endif; ?>
                </td>
                <td style='padding:60px 0'><a href="<?php echo e(route('CTNA.show_monan', ['id'=>$monan->MaMon])); ?>"><button class='btn btn-info'>Chi tiết</button></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class='col-12 d-flex justify-content-center' style='margin-top:20px'>
    <?php echo e($dsMonAn->links()); ?>

    </div>
    
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Subject\Laravel\BaiTap\CongThucNauAn\resources\views/index.blade.php ENDPATH**/ ?>
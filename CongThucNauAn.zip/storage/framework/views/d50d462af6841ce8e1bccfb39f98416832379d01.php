<?php $__env->startSection('active_binhluan'); ?>class="active has-sub"<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div  id="notify_comment" ></div>
<div class='form-create'>
    <table class='table'>
        <thead class='thead-dark'>
            <tr class='size-14'>
                <th>Mã món</th>
                <th>Tên món</th>
                <th>Username</th>
                <th>Nội dung</th>
                <th>Trạng thái</th>
                <th>Ghi chú</th>
            </tr>
        </thead>
        <tbody style='text-align:center'>
            <tr>
            <?php $__currentLoopData = $dsBinhLuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $binhluan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($binhluan->MaMon); ?></td>
                <td><?php echo e($binhluan->TenMon); ?></td>
                <td><?php echo e($binhluan->Username); ?></td>
                <td><?php echo e($binhluan->NoiDung); ?> </td>
                <td><?php echo e($binhluan->TrangThai); ?></td>
                <td>
                <?php if($binhluan->TrangThai == 0 ): ?>
                    <div style='margin-bottom:3px'>
                    <input type="button" data-TrangThai="0" id="<?php echo e($binhluan->MaMon); ?>"  class="btn btn-primary  binhluan_duyet_btn" value="Duyệt" >

                        <!-- <a href="#" class='link_duyet'>Duyệt</a> -->
                    </div>
                    <?php else: ?> 
                    <div>
                        <!-- <a href="#" class='link_duyet'>Xóa</a> -->
                    <input type="button" data-TrangThai="1" id="<?php echo e($binhluan->MaMon); ?>"  class="btn btn-danger binhluan_xoa_btn" value="Xoá" >
                    </div> 
                    <?php endif; ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Subject\Laravel\BaiTap\CongThucNauAn\resources\views/binhluan.blade.php ENDPATH**/ ?>
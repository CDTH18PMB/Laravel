<?php $__env->startSection('active_index'); ?>class="active has-sub"<?php $__env->stopSection(); ?>
<?php $__env->startSection('url'); ?>../<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('CTNA.index')); ?>"><button class='btn btn-dark' style='margin:0 0 15px 20px'>Quay lại</button></a>


<?php $__currentLoopData = $chitiet_monan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chitiet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(route('CTNA.destroy_monan', ['id'=>$chitiet->MaMon])); ?>"><button class='btn btn-danger' style='margin:0 0 15px 5px'>Xóa</button></a>


<form method='POST' action="<?php echo e(route('CTNA.update_monan',['id'=>$chitiet->MaMon])); ?>">
    <?php echo csrf_field(); ?>
    <div class='form-create'>
        <div class='row'>
            <div class='col-sm-8'>
                <div class='row'>
                    <div class='col-sm-4'>
                        <div class='form-group'>
                            <label for="MaMon">Mã món</label>
                            <input type="text" class='form-control' name='MaMon' value='<?php echo e($chitiet->MaMon); ?>' disabled>
                        </div>
                    </div>                                
                    <div class='col-sm-4'>
                        <div class='form-group'>
                            <label for="TenMon">Tên món</label>
                            <input type="text" class='form-control' name='TenMon' value='<?php echo e($chitiet->TenMon); ?>'>
                        </div>
                    </div>
                    <div class='col-sm-4'>
                        <div class='form-group'>
                            <label for="NguoiTao">Người tạo</label>
                            <input type="text" class='form-control' name='NguoiTao' value='<?php echo e($chitiet->NguoiTao); ?>'>
                        </div>
                    </div>
                </div>
                <div class='row'>
                    <div class='col-sm-6'>
                        <div class='form-group'>
                            <label for="DoKho">Độ khó</label>
                            <input type="text" class='form-control' name='DoKho' value='<?php echo e($chitiet->DoKho); ?>'>
                        </div>
                    </div>                                
                    <div class='col-sm-6'>
                        <div class='form-group'>
                            <label for="ThoiGianNau">Thời gian nấu</label>
                            <input type="text" class='form-control' name='ThoiGianNau' value='<?php echo e($chitiet->ThoiGianNau); ?>'>
                        </div>
                    </div>
                </div>
                <div class='row'>
                    <div class='col-sm-6'>
                        <div class='form-group'>
                            <label for="LuotXem">Lượt xem</label>
                            <input type="text" class='form-control' name='LuotXem' value='<?php echo e($chitiet->LuotXem); ?>'>
                        </div>
                    </div>
                    <div class='col-sm-6'>
                        <div class='form-group'>
                            <label for="LuotThich">Lượt thích</label>
                            <input type="text" class='form-control' name='LuotThich' value='<?php echo e($chitiet->LuotThich); ?>'>
                        </div>
                    </div>
                </div>

                <div class='row'>
                    <div class='col-sm-6'>
                        <div class='form-group'>
                            <label for="LoaiMon">Loại món</label>
                            <select name="LoaiMon" class='form-control'>
                                <option value="<?php echo e($chitiet->LoaiMon); ?>">
                                <?php $__currentLoopData = $dsTenLoai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenloai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($tenloai->TenLoai); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </option>
                                <?php $__currentLoopData = $dsDanhMuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key->MaLoai); ?>"><?php echo e($key->TenLoai); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>

            </div>
            <div class='col-sm-4'>
                <div class='form-group'>
                    <label for="AnhDaiDien">Ảnh đại diện</label>
                    <img src="../images/no-image.jpg" alt="image" id='img_MonAn' style='width: 100%; height: 250px'>
                    <span class='btn btn-outline-dark btn-file'><input type="file" id='inp_MonAn' class='form-control' name='AnhDaiDien'>Chọn hình</span>
                </div>
            </div>
        </div>

        <div class='row'>
            <div class='col-sm-6'>
                <div class='form-group'>
                    <label for="MoTa">Mô tả</label>
                    <textarea name="MoTa" cols="30" rows="5" class='form-control'><?php echo e($chitiet->MoTa); ?></textarea>
                </div>
            </div>                                
            <div class='col-sm-6'>
                <div class='form-group'>
                    <label for="NguyenLieu">Nguyên liệu</label>
                    <textarea name="NguyenLieu" cols="30" rows="5" class='form-control'><?php echo e($chitiet->NguyenLieu); ?></textarea>
                </div>
            </div>
        </div>

        <p>Các bước thực hiện</p>
        <div class='hr'></div>

        <div class='row' style='margin-bottom:25px'>
            <div class='col-sm-4'>
                <img src="../images/No-image.jpg" alt="hình ảnh" id='image' style='width: 100%; height: 240px'>
                <span class='btn btn-outline-dark btn-file'>Đổi hình<input type='file' id="inputIMG"></span>
            </div>
            <div class='col-sm-8'>
                <textarea name="HuongDan" cols="30" rows="11" class='form-control'></textarea>
            </div> 
        </div>
        
        <div class='hr'></div>
        <button class='btn btn-primary' style='width:100%'>Cập nhật</button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HoangLam\Desktop\CongThucNauAn\resources\views/chitiet_monan.blade.php ENDPATH**/ ?>
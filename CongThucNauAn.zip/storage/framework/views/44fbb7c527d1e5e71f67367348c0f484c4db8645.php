<?php $__env->startSection('active_taikhoan'); ?>class="active has-sub"<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style='margin: 0 0 10px 20px'>
    <a href="<?php echo e(route('CTNA.create_taikhoan')); ?>"><button class='btn btn-primary'>Thêm</button></a>
</div>
<div class='form-create'>
    <table class='table'>
        <thead class='thead-dark'>
            <tr class='size-14'>
                <th>Tài khoản</th>
                <th>Ảnh đại diện</th>
                <th>Mật khẩu</th>
                <th>Họ tên</th>
                <th>SĐT</th>
                <th>Email</th>
                <th>Loại</th>
                <th>Trạng thái</th>
                <th>Ghi chú</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dsTaiKhoan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style='text-align:center'>
                <td style='padding:50px 0'><?php echo e($ds->Username); ?></td>
                <td><img src="images/icon/avatar-big-01.jpg" alt="avatar" width='100px' height='100px'></td>
                <td style='padding:50px 0'><?php echo e($ds->Password); ?></td>
                <td style='padding:50px 0'><?php echo e($ds->HoTen); ?></td>
                <td style='padding:50px 0'><?php echo e($ds->SDT); ?></td>
                <td style='padding:50px 0'><?php echo e($ds->Email); ?></td>
                <td style='padding:50px 0'><?php echo e($ds->LoaiTK); ?></td>
                <td style='padding:50px 0'><?php echo e($ds->TrangThai); ?></td>
                <td style='padding:40px 0'><a href="<?php echo e(route('CTNA.show_taikhoan', ['id'=>$ds->Username])); ?>"><button class='btn btn-info'>Chi tiết</button></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HoangLam\Desktop\CongThucNauAn\resources\views/TaiKhoan.blade.php ENDPATH**/ ?>
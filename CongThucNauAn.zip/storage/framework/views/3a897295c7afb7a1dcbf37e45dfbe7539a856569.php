<?php $__env->startSection('active_index'); ?>class="active has-sub"<?php $__env->stopSection(); ?>
<?php $__env->startSection('url'); ?>../<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('CTNA.index')); ?>"><button class='btn btn-dark' style='margin:0 0 15px 20px'>Quay lại</button></a>


<?php $__currentLoopData = $chitiet_monan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chitiet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<!-- Đã xóa -->
<?php if($chitiet->TrangThai == 0): ?>
<a href="<?php echo e(route('CTNA.restore', ['id'=>$chitiet->MaMon])); ?>"><button class='btn btn-success' style='margin:0 0 15px 5px'>Hủy xóa</button></a>
<?php else: ?>
<a href="<?php echo e(route('CTNA.delete', ['id'=>$chitiet->MaMon])); ?>"><button class='btn btn-danger' style='margin:0 0 15px 5px'>Xóa</button></a>
<?php endif; ?>

<form method='POST' action="<?php echo e(route('CTNA.update_monan',['id'=>$chitiet->MaMon])); ?>" name='CreateProduct' enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class='form-create'>
        <div class='row'>
            <div class='col-sm-8'>
                <div class='row'>
                    <div class='col-sm-4'>
                        <div class='form-group'>
                            <label for="MaMon">Mã món</label>
                            <input type="text" class='form-control' name='MaMon' value='<?php echo e($chitiet->MaMon); ?>' disabled>
                        </div>
                    </div>                                
                    <div class='col-sm-4'>
                        <div class='form-group'>
                            <label for="TenMon">Tên món</label>
                            <input type="text" class='form-control' name='TenMon' value='<?php echo e($chitiet->TenMon); ?>'>
                        </div>
                    </div>
                    <div class='col-sm-4'>
                        <div class='form-group'>
                            <label for="NguoiTao">Người tạo</label>
                            <select class='form-control' name="NguoiTao" id="NguoiTao">
                                <option value="<?php echo e($chitiet->NguoiTao); ?>"><?php echo e($chitiet->NguoiTao); ?></option>
                                <?php $__currentLoopData = $dsTaiKhoan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tk->username); ?>"><?php echo e($tk->username); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class='row'>
                    <div class='col-sm-6'>
                        <div class='form-group'>
                            <label for="DoKho">Độ khó</label>
                            <input type="text" class='form-control' name='DoKho' value='<?php echo e($chitiet->DoKho); ?>'>
                        </div>
                    </div>                                
                    <div class='col-sm-6'>
                        <div class='form-group'>
                            <label for="ThoiGianNau">Thời gian nấu</label>
                            <input type="text" class='form-control' name='ThoiGianNau' value='<?php echo e($chitiet->ThoiGianNau); ?>'>
                        </div>
                    </div>
                </div>
                <div class='row'>
                    <div class='col-sm-6'>
                        <div class='form-group'>
                            <label for="LuotXem">Lượt xem</label>
                            <input type="number" class='form-control' min='0' name='LuotXem' value='<?php echo e($chitiet->LuotXem); ?>'>
                        </div>
                    </div>
                    <div class='col-sm-6'>
                        <div class='form-group'>
                            <label for="LuotThich">Lượt thích</label>
                            <input type="number" class='form-control' min='0' name='LuotThich' value='<?php echo e($chitiet->LuotThich); ?>'>
                        </div>
                    </div>
                </div>

                <div class='row'>
                    <div class='col-sm-6'>
                        <div class='form-group'>
                            <label for="LoaiMon">Loại món</label>
                            <select name="LoaiMon" class='form-control'>
                            
                                <option value="<?php echo e($loaimon); ?>"><?php echo e($tenloai); ?></option>

                                <?php $__currentLoopData = $dsDanhMuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key->MaLoai); ?>"><?php echo e($key->TenLoai); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>

            </div>
            <div class='col-sm-4'>
                <div class='form-group'>
                    <label for="AnhDaiDien">Ảnh đại diện</label>
                    <img src="../images/<?php echo e($chitiet->TenMon); ?>/anhdaidien.jpg" alt="image" id='img_Create_MonAn' name='img_Create_MonAn' style='width: 100%; height: 250px'>
                    <span class='btn btn-outline-dark btn-file'><input type="file" name='inp_Create_MonAn' id='inp_Create_MonAn' class='form-control'>Chọn hình</span>
                </div>
            </div>
        </div>

        <div class='row'>
            <div class='col-sm-6'>
                <div class='form-group'>
                    <label for="MoTa">Mô tả</label>
                    <textarea name="MoTa" cols="30" rows="5" class='form-control'><?php echo e($chitiet->MoTa); ?></textarea>
                </div>
            </div>                                
            <div class='col-sm-6'>
                <div class='form-group'>
                    <label for="NguyenLieu">Nguyên liệu</label>
                    <textarea name="NguyenLieu" cols="30" rows="5" class='form-control'><?php echo e($chitiet->NguyenLieu); ?></textarea>
                </div>
            </div>
        </div>

        <p>Các bước thực hiện</p><hr>
        <input name='count' value='<?php echo e(count($dsHuongDan)); ?>' hidden>

        
        <div id='HuongDan'>
        <?php for($i = 1; $i <= count($dsHuongDan); $i++): ?>
            <div id='div_buoc_<?php echo e($i); ?>' class='row' style='margin-bottom:25px'>
                <div class='col-sm-4'>
                    <img src="../images/<?php echo e($chitiet->TenMon); ?>/<?php echo e($dsHuongDan[$i-1]->HinhAnh); ?>" alt="hình ảnh" id='img_Buoc_<?php echo e($i); ?>' style='width: 100%; height: 240px'>
                    <span class='btn btn-outline-dark btn-file'>Đổi hình<input type='file' id="inp_Buoc_<?php echo e($i); ?>" name='inp_Buoc_<?php echo e($i); ?>'></span>
                </div>
                <div class='col-sm-8'>
                    <textarea id='Buoc_<?php echo e($i); ?>' name='Buoc_<?php echo e($i); ?>' cols="30" rows="11" class='form-control'><?php echo e($dsHuongDan[$i-1]->CacBuocLam); ?></textarea>
                </div> 
            </div>
        <?php endfor; ?>
        </div>

        <?php if($chitiet->TrangThai == 1): ?>
        <center>
            <button type='button' class='btn btn-warning' id="addStep" style='border-radius:10px; width:40%; margin-top:20px'>Thêm bước</button>
        </center>
        <hr>
        <button type='submit' class='btn btn-primary' style='width:100%'>Cập nhật</button>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Subject\Laravel\BaiTap\CongThucNauAn\resources\views/chitiet_monan.blade.php ENDPATH**/ ?>
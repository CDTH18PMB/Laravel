<?php $__env->startSection('active_index'); ?>class="active has-sub"<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style='margin: 0 0 10px 20px'>
    <a href="<?php echo e(route('CTNA.create_monan',['steps'=>1])); ?>"><button class='btn btn-primary'>Thêm</button></a>
</div>

<div class='form-create'>
    <table class='table'>
        <thead class='thead-dark'>
            <tr class='size-14'>
                <th>Mã món</th>
                <th>Tên món</th>
                <th>Ảnh đại diện</th>
                <th>Độ khó</th>
                <th>Thời gian nấu</th>
                <th>Người tạo</th>
                <th>Trạng thái</th>
                <th>Ghi chú</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dsMonAn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class='size-12'>
                <td style='padding:70px 0'><?php echo e($monan->MaMon); ?></td>
                <td style='padding:70px 0'><?php echo e($monan->TenMon); ?></td>
                <td><img src="images/bg-title-01.jpg" alt="image" width='200px' height='200px'></td>
                <td style='padding:70px 0'><?php echo e($monan->DoKho); ?></td>
                <td style='padding:70px 0'><?php echo e($monan->ThoiGianNau); ?></td>
                <td style='padding:70px 0'><?php echo e($monan->NguoiTao); ?></td>
                <td style='padding:70px 0'><?php echo e($monan->TrangThai); ?></td>
                <td style='padding:60px 0'><a href="<?php echo e(route('CTNA.show_monan', ['id'=>$monan->MaMon])); ?>"><button class='btn btn-info'>Chi tiết</button></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HoangLam\Desktop\CongThucNauAn\resources\views/index.blade.php ENDPATH**/ ?>
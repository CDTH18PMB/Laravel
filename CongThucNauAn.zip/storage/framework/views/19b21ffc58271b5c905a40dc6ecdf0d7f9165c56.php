<?php $__env->startSection('active_danhmuc'); ?>class="active has-sub"<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style='margin: 0 0 10px 20px'>
    <a href="<?php echo e(route('CTNA.create_danhmuc')); ?>"><button class='btn btn-primary'>Thêm</button></a>
</div>
<div style='margin: 0 0 10px 20px'>
<form class="form-header" action="timkiem" method="get">
                                <input class="au-input au-input--xl" type="text" name="key" placeholder="Search for datas &amp; reports..." />
                                <button class="au-btn--submit" type="submit">
                                    <i class="zmdi zmdi-search"></i>
                                </button>
                            </form></div>
<div class='form-create'>
    <table class='table'>
        <thead class='thead-dark'>
            <tr style='text-align:center'>
                <th>Mã loại</th>
                <th>Tên loại</th>
                <th>Trạng Thái</th>
                <th colspan='2'>Ghi chú</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dsDanhMuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style='text-align:center'>
                <td><?php echo e($ds->MaLoai); ?></td>
                <td><?php echo e($ds->TenLoai); ?></td>
                <td><?php echo e($ds->TrangThai); ?></td>
                <td>
                <a href="<?php echo e(route('CTNA.show_danhmuc', ['id'=>$ds->MaLoai])); ?>"><button class='btn btn-info'>Sửa</button>
                <a href="<?php echo e(route('CTNA.destroy_danhmuc', ['id'=>$ds->MaLoai])); ?>"><button class='btn btn-danger'>Xóa</button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Subject\Laravel\BaiTap\CongThucNauAn\resources\views/danhmuc.blade.php ENDPATH**/ ?>
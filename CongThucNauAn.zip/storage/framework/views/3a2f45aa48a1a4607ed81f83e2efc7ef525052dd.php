<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $chitiet_danhmuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chitiet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(route('CTNA.danhmuc')); ?>"><button class='btn btn-dark' style='margin:0 0 15px 20px'>Quay lại</button></a>
<form method='POST' action="<?php echo e(route('CTNA.show_update_danhmuc',['id'=>$chitiet->MaLoai])); ?>"> 
    <?php echo csrf_field(); ?>
    <div class='form-create'>
        
        <div class='form-group'>
            <label for="LoaiMon">Tên Loại</label>
            <input type="text" class='form-control' name='TenLoai' value ='<?php echo e($chitiet->TenLoai); ?>' > 
        </div>
        
        <button type='submit' class='btn btn-primary'>Sửa</button>
    </div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Subject\Laravel\BaiTap\CongThucNauAn\resources\views/chitiet_danhmuc.blade.php ENDPATH**/ ?>
<?php $__env->startSection('active_duyet'); ?>class="active has-sub"<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container box"><h4 align="left" >Tìm kiếm</h4><br />   
   <div class="form-group">
    <input type="text" name="country_name" id="country_name"  class="form-control input-lg" placeholder="Nhập vào ô tìm kiếm" />
    <div id="countryList"><br>
    </div>
  </div>
  <?php echo e(csrf_field()); ?>

</div>
<div  id="notify_comment"  ></div>

<div class='form-create' >

    <table class='table'>
        <thead class='thead-dark'>
            <tr class='size-14'>
                <th>Mã món</th>
                <th>Người tạo</th>
                <th>Tên món</th>
                <th>Ảnh đại diện</th>
                <th>Độ khó</th>
                <th>Thời gian nấu</th>
                <th>Loại món</th>
                <th>Trạng thái</th>
                <th>Ghi chú</th>
            </tr>
        </thead>
        <tbody>

        <?php $__currentLoopData = $dsDuyetCongThuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duyetct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style='text-align:center'>
                <td style='padding:70px 0'><?php echo e($duyetct->MaMon); ?></td>
                <td style='padding:70px 0'><?php echo e($duyetct->NguoiTao); ?></td>
                <td style='padding:70px 0'><?php echo e($duyetct->TenMon); ?></td>
                <td><img src="images/<?php echo e($duyetct->TenMon); ?>/<?php echo e($duyetct->AnhDaiDien); ?>" alt="image" width='200px' height='200px'></td>
                <td style='padding:70px 0'><?php echo e($duyetct->DoKho); ?></td>
                <td style='padding:70px 0'><?php echo e($duyetct->ThoiGianNau); ?></td>
                <td style='padding:70px 0'><?php echo e($duyetct->LoaiMon); ?></td>
                <td style='padding:70px 0'><?php echo e($duyetct->TrangThai); ?></td>
                <td >
                    <div style='margin-bottom:3px'>
                        <a href="<?php echo e(route('CTNA.show_monan', ['id'=>2])); ?>" class='link_duyet'>Chi tiết</a>
                    </div>
                    <?php if($duyetct->TrangThai == 0 ): ?>
                    <div style='margin-bottom:3px'>
                    <input type="button" data-TrangThai="0" id="<?php echo e($duyetct->MaMon); ?>"  class="btn btn-primary  congthuc_duyet_btn" value="Duyệt" >
                    </div>
                    <?php else: ?> 
                    <div>
                    <input type="button" data-TrangThai="1" id="<?php echo e($duyetct->MaMon); ?>"  class="btn btn-danger congthuc_xoa_btn" value="Xoá" >
                    </div> 
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Subject\Laravel\BaiTap\CongThucNauAn\resources\views/duyetcongthuc.blade.php ENDPATH**/ ?>
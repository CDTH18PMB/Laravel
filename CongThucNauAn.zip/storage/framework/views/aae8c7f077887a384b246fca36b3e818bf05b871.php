<?php $__env->startSection('active_taikhoan'); ?>class="active has-sub"<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class='row'>
    <div class="col-sm-6">
        <div style='margin: 0 0 10px 20px'>
            <a href="<?php echo e(route('CTNA.create_taikhoan')); ?>"><button class='btn btn-primary'>Thêm</button></a>
        </div>
    </div>
    <div class="col-sm-6">
        <div class='form-group' style='margin: 0 20px 0px 0px'>
                <input type="search" id="search_username" class='form-control' placeholder='Nhập tài khoản để tìm'>
                <div id="list_username"></div>
        </div>
        <?php echo e(csrf_field()); ?>

    </div>
</div>
<div class='form-create'>
    <table class='table'>
        <thead class='thead-dark'>
            <tr class='size-14'>
                <th style='text-align:center'>Tài khoản</th>
                <th style='text-align:center'>Ảnh đại diện</th>
                <th style='text-align:center'>Họ tên</th>
                <th style='text-align:center'>SĐT</th>
                <th style='text-align:center'>Email</th>
                <th style='text-align:center'>Loại</th>
                <th style='text-align:center'>Trạng thái</th>
                <th style='text-align:center'>Ghi chú</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dsTaiKhoan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style='text-align:center'>
                <td style='padding:50px 0'><?php echo e($ds->username); ?></td>
                <td><img src="images/avatar/<?php echo e($ds->AnhDaiDien); ?>"  alt="avatar" width='100px' height='100px'></td>
                <td style='padding:50px 0'><?php echo e($ds->HoTen); ?></td>
                <td style='padding:50px 0'><?php echo e($ds->SDT); ?></td>
                <td style='padding:50px 0'><?php echo e($ds->Email); ?></td>
                <td style='padding:50px 0'><?php echo e($ds->LoaiTK); ?></td>
                <td style='padding:50px 0'><?php echo e($ds->TrangThai); ?></td>
                <td style='padding:40px 0'><a href="<?php echo e(route('CTNA.show_taikhoan', ['id'=>$ds->username])); ?>"><button class='btn btn-info'>Chi tiết</button></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<script src="<?php echo e(URL::asset('vendor/jquery-3.2.1.min.js')); ?>"></script>
<script>
$(document).ready(function(){
    $("#search_username").keyup(function(){
        var query = $(this).val();
        // if(query != ''){
            var _token = $('input[name="_token"]').val();
            $.ajax({
                url:"<?php echo e(route('CTNA.search_taikhoan')); ?>",
                method:"POST",
                data:{query:query, _token:_token},
                success:function(data){
                    $('#list_username').fadeIn();  
                    $('#list_username').html(data);
                }
            });
        // }
    });
});
$(document).on('click', 'li', function(){  
    $('#search_username').val($(this).text());  
    $('#list_username').fadeOut();  
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Subject\Laravel\BaiTap\CongThucNauAn\resources\views/TaiKhoan.blade.php ENDPATH**/ ?>